Mimo Arabic - حزمة رفع نظيفة إلى GitHub

مهم: لا ترفع ملف ZIP نفسه إلى المستودع. فك ضغطه أولاً، ثم ارفع كل ما بداخله إلى جذر مستودع GitHub.

يجب أن يكون شكل المستودع بعد الرفع هكذا:
- .github/workflows/android.yml
- app/
- build.gradle.kts
- gradle.properties
- settings.gradle.kts
- README_AR.md

بعد رفع الملفات إلى الفرع main:
1) افتح تبويب Actions.
2) افتح Build Mimo Arabic APK.
3) انتظر انتهاء البناء.
4) إذا نجح، افتح عملية البناء ثم حمّل MimoArabic-APK من Artifacts.

المتطلبات: GitHub Actions مفعّل للمستودع. يفضّل مستودع جديد ونظيف باسم MimoArabic.
هذه الحزمة تبني نسخة Debug للتجربة، وليست نسخة Release للنشر على Google Play.
