package com.mimoarabic.app

import android.content.Context
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Ink = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Mint = Color(0xFF35D6A0)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Ink, surface = Panel)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { MimoApp() }
            }
        }
    }
}

private data class Lesson(
    val title: String, val subtitle: String, val explanation: String,
    val example: String, val task: String, val expected: String
)

private val lessons = listOf(
    Lesson("أهلاً بعالم HTML", "تعرّف على لغة بناء صفحات الويب",
        "HTML هي اللغة التي نستخدمها لوصف بنية صفحة الويب. نكتب العناصر داخل وسوم، ولكل وسم وظيفة محددة.",
        "<h1>مرحباً بالعالم</h1>", "اكتب عنواناً رئيسياً يحتوي على: أنا أتعلم البرمجة",
        "<h1>أنا أتعلم البرمجة</h1>"),
    Lesson("العناوين والفقرات", "نظّم محتوى صفحتك",
        "استخدم h1 إلى h6 للعناوين، واستخدم p لكتابة الفقرات. اختر الوسم حسب معنى المحتوى.",
        "<h1>عنوان الصفحة</h1>\n<p>هذه فقرة قصيرة.</p>",
        "أنشئ عنوان h1 نصه مرحباً، وفقرة نصها هذه أول صفحة لي.",
        "<h1>مرحباً</h1>\n<p>هذه أول صفحة لي.</p>"),
    Lesson("أنشئ رابطاً", "اربط صفحتك بالإنترنت",
        "يُستخدم الوسم a لإنشاء رابط. الخاصية href تحدد الوجهة التي ينتقل إليها المستخدم.",
        "<a href=\"https://example.com\">افتح الموقع</a>",
        "أنشئ رابطاً إلى https://example.com واجعل نصه زُر موقعي.",
        "<a href=\"https://example.com\">زُر موقعي</a>")
)

private enum class Screen { HOME, PATH, LESSON, PROFILE }

@Composable
private fun MimoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mimo_progress", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var lessonIndex by remember { mutableIntStateOf(prefs.getInt("lesson", 0).coerceIn(0, lessons.lastIndex)) }
    var draft by remember { mutableStateOf(prefs.getString("draft_$lessonIndex", lessons[lessonIndex].example) ?: lessons[lessonIndex].example) }
    var completed by remember { mutableStateOf(prefs.getBoolean("done_$lessonIndex", false)) }

    fun openLesson(i: Int) {
        lessonIndex = i.coerceIn(0, lessons.lastIndex)
        draft = prefs.getString("draft_$lessonIndex", lessons[lessonIndex].example) ?: lessons[lessonIndex].example
        completed = prefs.getBoolean("done_$lessonIndex", false)
        prefs.edit().putInt("lesson", lessonIndex).apply()
        screen = Screen.LESSON
    }

    val doneCount = (lessons.indices).count { prefs.getBoolean("done_$it", false) }

    Scaffold(
        containerColor = Ink,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(screen == Screen.HOME, { screen = Screen.HOME }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                NavigationBarItem(screen == Screen.PATH || screen == Screen.LESSON, { screen = Screen.PATH }, icon = { Icon(Icons.Default.Route, null) }, label = { Text("المسارات") })
                NavigationBarItem(screen == Screen.PROFILE, { screen = Screen.PROFILE }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حسابي") })
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                Screen.HOME -> HomeScreen(doneCount, { openLesson(lessonIndex) }, { screen = Screen.PATH })
                Screen.PATH -> PathScreen({ i -> prefs.getBoolean("done_$i", false) }, ::openLesson)
                Screen.LESSON -> LessonScreen(
                    lessons[lessonIndex], lessonIndex, draft, completed,
                    onDraft = { draft = it; prefs.edit().putString("draft_$lessonIndex", it).apply() },
                    onComplete = { completed = true; prefs.edit().putBoolean("done_$lessonIndex", true).apply() },
                    onNext = { if (lessonIndex < lessons.lastIndex) openLesson(lessonIndex + 1) else screen = Screen.PATH },
                    onBack = { screen = Screen.PATH }
                )
                Screen.PROFILE -> ProfileScreen(doneCount)
            }
        }
    }
}

@Composable
private fun HomeScreen(done: Int, onContinue: () -> Unit, onPath: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مرحباً بك 👋", color = Muted)
                    Text("مستقبلك يبدأ بسطر كود", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(48.dp).background(Mint, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Code, null, tint = Ink)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("هدفك اليوم", color = Muted)
                    Text("تعلّم شيئاً جديداً في 10 دقائق", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(progress = { done.toFloat() / lessons.size }, modifier = Modifier.fillMaxWidth(), color = Mint)
                    Text("$done من ${lessons.size} دروس مكتملة", color = Muted, fontSize = 12.sp)
                    Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text("تابع التعلّم") }
                }
            }
        }
        item {
            Text("ابدأ مسارك", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth().clickable(onClick = onPath), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Language, null, tint = Mint, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("أساسيات تطوير الويب", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("HTML • البداية من الصفر", color = Muted, fontSize = 13.sp)
                    }
                    Icon(Icons.Default.ChevronLeft, null, tint = Muted)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallStat("الدروس", "$done/${lessons.size}", Modifier.weight(1f))
                SmallStat("السلسلة", "0 يوم", Modifier.weight(1f))
                SmallStat("النقاط", "${done * 20} XP", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SmallStat(label: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = Mint, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PathScreen(isDone: (Int) -> Boolean, onLesson: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("مسار تعلّم HTML", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("من أول وسم إلى صفحة ويب بسيطة", color = Muted)
        Spacer(Modifier.height(18.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(lessons.size) { i ->
                val lesson = lessons[i]
                Card(Modifier.fillMaxWidth().clickable { onLesson(i) }, colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(if (isDone(i)) Color(0xFF174D40) else Ink, CircleShape), contentAlignment = Alignment.Center) {
                            if (isDone(i)) Icon(Icons.Default.Check, null, tint = Mint) else Text("${i + 1}", color = Mint)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(lesson.title, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(lesson.subtitle, color = Muted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronLeft, null, tint = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonScreen(
    lesson: Lesson, index: Int, draft: String, completed: Boolean,
    onDraft: (String) -> Unit, onComplete: () -> Unit, onNext: () -> Unit, onBack: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var feedback by remember { mutableStateOf<String?>(null) }
    var previewRefresh by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, null, tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("الدرس ${index + 1} من ${lessons.size}", color = Muted, fontSize = 12.sp)
                LinearProgressIndicator(progress = { (index + 1f) / lessons.size }, modifier = Modifier.fillMaxWidth(), color = Mint)
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            item {
                Text(lesson.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(lesson.subtitle, color = Muted)
            }
            item {
                LessonCard("افهم الفكرة") { Text(lesson.explanation, color = Color.White, lineHeight = 24.sp) }
            }
            item {
                LessonCard("شاهد المثال") {
                    Text(lesson.example, color = Mint, fontSize = 14.sp)
                    TextButton(onClick = { clipboard.setText(AnnotatedString(lesson.example)) }) {
                        Icon(Icons.Default.ContentCopy, null); Text("نسخ المثال")
                    }
                }
            }
            item {
                LessonCard("تحدّيك العملي") {
                    Text(lesson.task, color = Color.White, lineHeight = 23.sp)
                    OutlinedTextField(
                        value = draft, onValueChange = onDraft, modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                        label = { Text("اكتب كود HTML هنا") },
                        textStyle = LocalTextStyle.current.copy(color = Mint, fontSize = 13.sp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mint, cursorColor = Mint)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { previewRefresh++ }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Visibility, null); Spacer(Modifier.width(5.dp)); Text("معاينة")
                        }
                        Button(onClick = {
                            val normalized = draft.trim().replace("\\s+".toRegex(), " ")
                            val target = lesson.expected.trim().replace("\\s+".toRegex(), " ")
                            if (normalized == target) {
                                feedback = "ممتاز! إجابتك مطابقة للتحدي."
                                onComplete()
                            } else feedback = "حاول مرة أخرى. راجع الوسوم والنص المطلوب."
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(5.dp)); Text("تحقق")
                        }
                    }
                    feedback?.let { Text(it, color = if (completed) Mint else Color(0xFFFFC36A), fontSize = 13.sp) }
                }
            }
            item {
                LessonCard("معاينة الصفحة") {
                    key(previewRefresh) { HtmlPreview(draft) }
                }
            }
        }
        Button(onClick = onNext, enabled = completed, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).height(52.dp)) {
            Text(if (index == lessons.lastIndex) "إنهاء المسار" else "الدرس التالي")
        }
    }
}

@Composable
private fun LessonCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Mint, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun HtmlPreview(code: String) {
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(150.dp),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = false
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.domStorageEnabled = false
                webViewClient = WebViewClient()
                setBackgroundColor(android.graphics.Color.WHITE)
            }
        },
        update = { view ->
            val html = "<!doctype html><html lang='ar' dir='rtl'><meta charset='utf-8'>" +
                "<meta name='viewport' content='width=device-width, initial-scale=1'>" +
                "<body style='font-family:sans-serif;padding:16px;color:#172033'>" + code + "</body></html>"
            view.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        }
    )
}

@Composable
private fun ProfileScreen(done: Int) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("ملفي التعليمي", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.AccountCircle, null, tint = Mint, modifier = Modifier.size(68.dp))
                Text("متعلم جديد", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("رحلتك في البرمجة تبدأ هنا", color = Muted)
                Spacer(Modifier.height(12.dp))
                Text("$done دروس مكتملة", color = Mint, fontWeight = FontWeight.Bold)
            }
        }
        Text("قريباً: الشارات، المستويات، الشهادات، ومزامنة تقدمك بين أجهزتك.", color = Muted, lineHeight = 24.sp)
    }
}
