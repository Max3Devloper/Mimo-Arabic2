# Jsoup يشير إلى مكتبات اختيارية غير موجودة على Android
-dontwarn org.jspecify.annotations.**
-dontwarn com.google.re2j.**
-dontwarn javax.annotation.**
