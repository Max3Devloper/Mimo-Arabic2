package com.koodi.learn.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HtmlValidatorTest {

    private val h1 = listOf("<h1>أنا أتعلم البرمجة</h1>")
    private val link = listOf("<a href=\"https://example.com\">زُر موقعي</a>")
    private val page = listOf("<h1>مرحباً</h1>\n<p>هذه أول صفحة لي.</p>")

    private fun ok(code: String, solutions: List<String>) =
        assertTrue("يجب قبول: $code", HtmlValidator.validate(code, solutions).passed)

    private fun issue(code: String, solutions: List<String>): Issue? {
        val r = HtmlValidator.validate(code, solutions)
        assertFalse("يجب رفض: $code", r.passed)
        return r.issue
    }

    @Test fun acceptsExactSolution() = ok("<h1>أنا أتعلم البرمجة</h1>", h1)

    @Test fun ignoresExtraSpacesAndNewlines() {
        ok("  <h1>  أنا   أتعلم\nالبرمجة  </h1>  ", h1)
        ok("<h1>مرحباً</h1>\n\n\n   <p>هذه أول صفحة لي.</p>", page)
        ok("<h1>مرحباً</h1><p>هذه أول صفحة لي.</p>", page)
    }

    @Test fun ignoresTagCase() = ok("<H1>أنا أتعلم البرمجة</H1>", h1)

    @Test fun acceptsSingleQuotesForAttributes() =
        ok("<a href='https://example.com'>زُر موقعي</a>", link)

    @Test fun ignoresAttributeAndClassOrder() {
        val sol = listOf("<div class=\"a b\" id=\"x\"></div>")
        ok("<div id=\"x\" class=\"b a\"></div>", sol)
    }

    @Test fun acceptsAnyOfSeveralSolutions() {
        val sols = listOf("<p><em>HTML</em></p>", "<p><i>HTML</i></p>")
        ok("<p><i>HTML</i></p>", sols)
        ok("<p><em>HTML</em></p>", sols)
    }

    @Test fun rejectsEmptyInput() {
        assertEquals(Issue.Empty, issue("", h1))
        assertEquals(Issue.Empty, issue("   \n ", h1))
    }

    @Test fun rejectsUnclosedTagEvenThoughBrowsersWouldFixIt() {
        assertEquals(Issue.Unclosed("h1"), issue("<h1>أنا أتعلم البرمجة", h1))
    }

    @Test fun reportsWrongText() =
        assertEquals(Issue.WrongText, issue("<h1>أنا أتعلم</h1>", h1))

    @Test fun reportsMissingTag() =
        assertEquals(Issue.MissingTag("p"), issue("<h1>مرحباً</h1>", page))

    @Test fun reportsUnexpectedTag() =
        assertEquals(Issue.UnexpectedTag("h2"), issue("<h1>أنا أتعلم البرمجة</h1><h2>x</h2>", h1))

    @Test fun reportsMissingAttribute() =
        assertEquals(Issue.Attribute("href"), issue("<a>زُر موقعي</a>", link))

    @Test fun reportsWrongAttributeValue() =
        assertEquals(Issue.Attribute("href"), issue("<a href=\"https://other.com\">زُر موقعي</a>", link))

    @Test fun reportsStructureWhenNestingDiffers() {
        val sol = listOf("<div><h2>x</h2></div>")
        assertEquals(Issue.Structure, issue("<div></div><h2>x</h2>", sol))
    }

    @Test fun voidTagsDoNotNeedClosing() =
        ok("<p>سطر<br>سطر</p>", listOf("<p>سطر<br>سطر</p>"))
}
