package com.koodi.learn.domain

import com.koodi.learn.data.LessonParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * يحمي محتوى lessons.json من الأخطاء عند إضافة دروس: كل درس يجب أن يكون قابلاً للحل،
 * وألا يكون الكود الابتدائي حلاً جاهزاً.
 */
class LessonsContentTest {

    private val lessons = LessonParser.parse(File("src/main/assets/lessons.json").readText(Charsets.UTF_8))

    @Test fun hasLessons() = assertTrue(lessons.isNotEmpty())

    @Test fun idsAreUnique() = assertEquals(lessons.size, lessons.map { it.id }.toSet().size)

    @Test fun everySolutionPassesItsOwnValidator() {
        for (l in lessons) for (s in l.solutions) {
            assertTrue("حل الدرس ${l.id} لا يجتاز المصحح: $s", HtmlValidator.validate(s, l.solutions).passed)
        }
    }

    @Test fun starterIsNotAlreadyASolution() {
        for (l in lessons) {
            assertFalse("الكود الابتدائي في ${l.id} يمر دون عمل", HtmlValidator.validate(l.starter, l.solutions).passed)
        }
    }

    @Test fun everyLessonHasHints() {
        for (l in lessons) assertTrue("الدرس ${l.id} بلا تلميحات", l.hints.isNotEmpty())
    }
}
