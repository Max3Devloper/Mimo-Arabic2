package com.koodi.learn.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class StreakCalculatorTest {

    @Test fun firstActivityStartsAtOne() =
        assertEquals(StreakState(100, 1), StreakCalculator.onActivity(StreakState(null, 0), 100))

    @Test fun sameDayDoesNotIncrease() {
        val s = StreakState(100, 3)
        assertEquals(s, StreakCalculator.onActivity(s, 100))
    }

    @Test fun nextDayIncreases() =
        assertEquals(StreakState(101, 4), StreakCalculator.onActivity(StreakState(100, 3), 101))

    @Test fun missedDayResetsToOne() =
        assertEquals(StreakState(103, 1), StreakCalculator.onActivity(StreakState(100, 7), 103))

    @Test fun displayedIsZeroWithoutActivity() =
        assertEquals(0, StreakCalculator.displayed(StreakState(null, 0), 100))

    @Test fun displayedKeepsStreakTodayAndYesterday() {
        assertEquals(5, StreakCalculator.displayed(StreakState(100, 5), 100))
        assertEquals(5, StreakCalculator.displayed(StreakState(100, 5), 101))
    }

    @Test fun displayedBreaksAfterAFullMissedDay() =
        assertEquals(0, StreakCalculator.displayed(StreakState(100, 5), 102))
}
