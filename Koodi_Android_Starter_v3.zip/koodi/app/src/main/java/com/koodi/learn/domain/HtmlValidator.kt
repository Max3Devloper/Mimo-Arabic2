package com.koodi.learn.domain

import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.TextNode
import kotlin.math.abs

/** سبب رفض الحل، بلغة يفهمها المتعلم. الواجهة تحوّله إلى رسالة عربية. */
sealed interface Issue {
    data object Empty : Issue
    data class Unclosed(val tag: String) : Issue
    data class MissingTag(val tag: String) : Issue
    data class UnexpectedTag(val tag: String) : Issue
    data class Attribute(val name: String) : Issue
    data object WrongText : Issue
    data object Structure : Issue
}

data class ValidationResult(val passed: Boolean, val issue: Issue? = null)

/**
 * مصحّح HTML يقارن شجرة DOM لا النص الخام.
 *
 * يقبل: اختلاف المسافات والأسطر، ترتيب الخصائص، علامات اقتباس مفردة أو مزدوجة،
 * ترتيب أسماء الـ class، وأي حل من قائمة الحلول المقبولة.
 * يرفض: وسماً غير مُغلق (حتى لو أصلحه المتصفح تلقائياً)، ونصاً أو وسماً أو خاصية مختلفة.
 *
 * هذا الملف لا يعتمد على Android، فيُختبر بسرعة على JVM.
 */
object HtmlValidator {

    private val VOID_TAGS = setOf("br", "hr", "img", "input", "meta", "link")
    private val TAG_REGEX = Regex("<(/?)([a-zA-Z][a-zA-Z0-9]*)[^>]*?(/?)>")
    private val WHITESPACE = Regex("\\s+")

    fun validate(userCode: String, solutions: List<String>): ValidationResult {
        if (userCode.isBlank()) return fail(Issue.Empty)
        findUnclosedTag(userCode)?.let { return fail(it) }

        val user = normalize(userCode)
        val candidates = solutions.map { normalize(it) }
        if (candidates.any { it == user }) return ValidationResult(passed = true)

        // نشخّص الفرق مع أقرب حل مقبول حتى تكون الرسالة مفيدة
        val closest = candidates.minByOrNull { tagDistance(it, user) } ?: return fail(Issue.Structure)
        return fail(diagnose(closest, user))
    }

    private fun fail(issue: Issue) = ValidationResult(passed = false, issue = issue)

    // ---------- فحص الإغلاق (Jsoup يصلح الأخطاء بصمت، ونحن نريد تعليم الإغلاق) ----------

    private fun findUnclosedTag(code: String): Issue.Unclosed? {
        val stack = ArrayDeque<String>()
        for (match in TAG_REGEX.findAll(code)) {
            val closing = match.groupValues[1] == "/"
            val name = match.groupValues[2].lowercase()
            val selfClosing = match.groupValues[3] == "/"
            if (name in VOID_TAGS || selfClosing) continue
            when {
                !closing -> stack.addLast(name)
                stack.lastOrNull() == name -> stack.removeLast()
                else -> return Issue.Unclosed(stack.lastOrNull() ?: name)
            }
        }
        return stack.lastOrNull()?.let { Issue.Unclosed(it) }
    }

    // ---------- تمثيل DOM مبسّط وقابل للمقارنة ----------

    private sealed interface Node
    private data class El(val tag: String, val attrs: List<Pair<String, String>>, val kids: List<Node>) : Node
    private data class Tx(val text: String) : Node

    private fun normalize(html: String): List<Node> = childrenOf(Jsoup.parseBodyFragment(html).body())

    private fun childrenOf(parent: Element): List<Node> = parent.childNodes().mapNotNull { node ->
        when (node) {
            is TextNode -> node.text().trim().takeIf { it.isNotEmpty() }?.let { Tx(it) }
            is Element -> El(
                tag = node.normalName(),
                attrs = node.attributes().asList()
                    .map { it.key.lowercase() to normalizeValue(it.key, it.value) }
                    .sortedBy { it.first },
                kids = childrenOf(node),
            )
            else -> null // التعليقات وغيرها
        }
    }

    private fun normalizeValue(key: String, value: String): String =
        if (key.equals("class", ignoreCase = true)) {
            value.split(WHITESPACE).filter { it.isNotEmpty() }.sorted().joinToString(" ")
        } else {
            value.trim()
        }

    // ---------- التشخيص ----------

    private fun tagCounts(nodes: List<Node>, acc: MutableMap<String, Int> = mutableMapOf()): Map<String, Int> {
        for (n in nodes) if (n is El) {
            acc[n.tag] = (acc[n.tag] ?: 0) + 1
            tagCounts(n.kids, acc)
        }
        return acc
    }

    private fun tagDistance(a: List<Node>, b: List<Node>): Int {
        val x = tagCounts(a)
        val y = tagCounts(b)
        return (x.keys + y.keys).sumOf { abs((x[it] ?: 0) - (y[it] ?: 0)) }
    }

    private fun elements(nodes: List<Node>, out: MutableList<El> = mutableListOf()): List<El> {
        for (n in nodes) if (n is El) {
            out += n
            elements(n.kids, out)
        }
        return out
    }

    private fun texts(nodes: List<Node>, out: MutableList<String> = mutableListOf()): List<String> {
        for (n in nodes) when (n) {
            is Tx -> out += n.text
            is El -> texts(n.kids, out)
        }
        return out
    }

    private fun diagnose(expected: List<Node>, user: List<Node>): Issue {
        val e = tagCounts(expected)
        val u = tagCounts(user)
        e.entries.firstOrNull { (u[it.key] ?: 0) < it.value }?.let { return Issue.MissingTag(it.key) }
        u.entries.firstOrNull { (e[it.key] ?: 0) < it.value }?.let { return Issue.UnexpectedTag(it.key) }

        val expectedEls = elements(expected)
        val userEls = elements(user)
        if (expectedEls.map { it.tag } == userEls.map { it.tag }) {
            for (i in expectedEls.indices) {
                val ea = expectedEls[i].attrs.toMap()
                val ua = userEls[i].attrs.toMap()
                val bad = ea.entries.firstOrNull { ua[it.key] != it.value }?.key
                    ?: ua.keys.firstOrNull { it !in ea }
                if (bad != null) return Issue.Attribute(bad)
            }
            if (texts(expected) != texts(user)) return Issue.WrongText
        }
        return Issue.Structure
    }
}
