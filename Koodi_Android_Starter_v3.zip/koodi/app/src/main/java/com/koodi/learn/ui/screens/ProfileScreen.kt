package com.koodi.learn.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.koodi.learn.R
import com.koodi.learn.ui.UiState
import com.koodi.learn.ui.components.StatCard
import com.koodi.learn.ui.components.panelColors

private data class Badge(val title: Int, val description: Int, val unlocked: Boolean)

@Composable
fun ProfileScreen(state: UiState) {
    val colors = MaterialTheme.colorScheme
    val total = state.lessons.size
    val badges = listOf(
        Badge(R.string.badge_first_title, R.string.badge_first_desc, state.doneCount >= 1),
        Badge(R.string.badge_half_title, R.string.badge_half_desc, total > 0 && state.doneCount * 2 >= total),
        Badge(R.string.badge_all_title, R.string.badge_all_desc, state.allDone),
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { Text(stringResource(R.string.profile_title), fontSize = 25.sp, fontWeight = FontWeight.Bold) }

        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = panelColors()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        Icons.Default.AccountCircle,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.size(68.dp),
                    )
                    Text(stringResource(R.string.profile_name), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text(stringResource(R.string.profile_tagline), color = colors.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        stringResource(R.string.profile_level, state.level),
                        color = colors.primary,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(stringResource(R.string.profile_lessons_done, state.doneCount), color = colors.onSurfaceVariant)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(
                    stringResource(R.string.stat_streak),
                    stringResource(R.string.streak_days, state.streak),
                    Modifier.weight(1f),
                )
                StatCard(
                    stringResource(R.string.stat_xp),
                    stringResource(R.string.xp_value, state.xp),
                    Modifier.weight(1f),
                )
            }
        }

        item { Text(stringResource(R.string.badges_title), fontSize = 20.sp, fontWeight = FontWeight.Bold) }

        items(badges.size) { i -> BadgeRow(badges[i]) }

        item {
            Text(
                stringResource(R.string.profile_soon),
                color = colors.onSurfaceVariant,
                lineHeight = 24.sp,
            )
        }
    }
}

@Composable
private fun BadgeRow(badge: Badge) {
    val colors = MaterialTheme.colorScheme
    val title = stringResource(badge.title)
    val status = stringResource(if (badge.unlocked) R.string.badge_unlocked else R.string.badge_locked)
    Card(
        modifier = Modifier.fillMaxWidth().semantics { contentDescription = "$title، $status" },
        colors = panelColors(),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (badge.unlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                contentDescription = null,
                tint = if (badge.unlocked) colors.primary else colors.onSurfaceVariant,
                modifier = Modifier.size(32.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    title,
                    fontWeight = FontWeight.Bold,
                    color = if (badge.unlocked) colors.onSurface else colors.onSurfaceVariant,
                )
                Text(stringResource(badge.description), color = colors.onSurfaceVariant, fontSize = 12.sp)
            }
        }
    }
}
