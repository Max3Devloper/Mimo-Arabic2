package com.koodi.learn.data

import android.content.Context
import com.koodi.learn.domain.Lesson

class LessonRepository(private val context: Context) {

    fun load(): List<Lesson> =
        context.assets.open("lessons.json").bufferedReader(Charsets.UTF_8).use {
            LessonParser.parse(it.readText())
        }
}
