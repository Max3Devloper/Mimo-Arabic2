package com.koodi.learn.ui

import com.koodi.learn.domain.Issue
import com.koodi.learn.domain.Lesson

enum class Screen { HOME, PATH, LESSON, PROFILE }

sealed interface Feedback {
    data object Success : Feedback
    data class Failure(val issue: Issue) : Feedback
}

const val XP_PER_LESSON = 30

/** مصدر الحقيقة الوحيد للواجهة. كل القيم المشتقة تُحسب منه، فلا تتعارض الشاشات مع بعضها. */
data class UiState(
    val screen: Screen = Screen.HOME,
    val lessons: List<Lesson> = emptyList(),
    val lessonIndex: Int = 0,
    val draft: String = "",
    val completedIds: Set<String> = emptySet(),
    val feedback: Feedback? = null,
    val hintsShown: Int = 0,
    val streak: Int = 0,
) {
    val lesson: Lesson get() = lessons[lessonIndex]
    val doneCount: Int get() = lessons.count { it.id in completedIds }
    val allDone: Boolean get() = lessons.isNotEmpty() && doneCount == lessons.size
    val isLessonCompleted: Boolean get() = lesson.id in completedIds
    val xp: Int get() = doneCount * XP_PER_LESSON
    val level: Int get() = xp / 100 + 1
    fun isDone(index: Int): Boolean = lessons[index].id in completedIds
}
