package com.koodi.learn

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.koodi.learn.ui.KoodiApp
import com.koodi.learn.ui.theme.KoodiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // التطبيق داكن دائماً: أيقونات أشرطة النظام فاتحة بغض النظر عن ثيم الجهاز
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        setContent {
            KoodiTheme { KoodiApp() }
        }
    }
}
