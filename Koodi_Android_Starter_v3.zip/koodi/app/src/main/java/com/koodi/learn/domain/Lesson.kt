package com.koodi.learn.domain

/**
 * درس واحد. المحتوى يأتي من assets/lessons.json لا من الكود،
 * فيمكن إضافة دروس دون لمس أي ملف Kotlin.
 *
 * @property starter الكود الذي يظهر في المحرر أول مرة.
 * @property solutions كل الحلول المقبولة (يكفي أن يطابق أحدها بنية DOM).
 * @property hints تلميحات متدرجة من الأخف إلى الأوضح.
 */
data class Lesson(
    val id: String,
    val title: String,
    val subtitle: String,
    val explanation: String,
    val example: String,
    val task: String,
    val starter: String,
    val solutions: List<String>,
    val hints: List<String>,
)
