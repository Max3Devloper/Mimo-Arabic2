package com.koodi.learn.domain

/**
 * يغلّف كود المتعلم بصفحة كاملة للمعاينة.
 * سياسة CSP تمنع السكربتات والشبكة حتى لو فُعّلت إعدادات WebView خطأً (دفاع بطبقتين).
 */
object PreviewHtml {
    fun wrap(code: String): String =
        "<!doctype html><html lang=\"ar\" dir=\"rtl\"><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
            "<meta http-equiv=\"Content-Security-Policy\" " +
            "content=\"default-src 'none'; style-src 'unsafe-inline'; img-src data:\">" +
            "<style>body{font-family:sans-serif;padding:16px;color:#172033;line-height:1.7}</style>" +
            "</head><body>" + code + "</body></html>"
}
