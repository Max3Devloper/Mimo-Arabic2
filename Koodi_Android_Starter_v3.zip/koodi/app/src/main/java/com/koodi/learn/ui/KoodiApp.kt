package com.koodi.learn.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.koodi.learn.R
import com.koodi.learn.ui.screens.HomeScreen
import com.koodi.learn.ui.screens.LessonScreen
import com.koodi.learn.ui.screens.PathScreen
import com.koodi.learn.ui.screens.ProfileScreen

@Composable
fun KoodiApp(vm: AppViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()

    // زر الرجوع يعمل داخل التطبيق؛ من الرئيسية فقط يخرج منه
    BackHandler(enabled = state.screen != Screen.HOME) { vm.back() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            // وضع التركيز: لا شريط سفلي أثناء الدرس
            if (state.screen != Screen.LESSON) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    NavigationBarItem(
                        selected = state.screen == Screen.HOME,
                        onClick = { vm.navigate(Screen.HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text(stringResource(R.string.nav_home)) },
                    )
                    NavigationBarItem(
                        selected = state.screen == Screen.PATH,
                        onClick = { vm.navigate(Screen.PATH) },
                        icon = { Icon(Icons.Default.Route, contentDescription = null) },
                        label = { Text(stringResource(R.string.nav_path)) },
                    )
                    NavigationBarItem(
                        selected = state.screen == Screen.PROFILE,
                        onClick = { vm.navigate(Screen.PROFILE) },
                        icon = { Icon(Icons.Default.Person, contentDescription = null) },
                        label = { Text(stringResource(R.string.nav_profile)) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            Crossfade(targetState = state.screen, label = "screen") { screen ->
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        state = state,
                        onContinue = vm::continueLearning,
                        onOpenPath = { vm.navigate(Screen.PATH) },
                    )
                    Screen.PATH -> PathScreen(state = state, onOpenLesson = vm::openLesson)
                    Screen.LESSON -> LessonScreen(
                        state = state,
                        onDraftChange = vm::onDraftChange,
                        onCheck = vm::check,
                        onHint = vm::showHint,
                        onReset = vm::resetDraft,
                        onNext = vm::next,
                        onBack = vm::back,
                    )
                    Screen.PROFILE -> ProfileScreen(state = state)
                }
            }
        }
    }
}
