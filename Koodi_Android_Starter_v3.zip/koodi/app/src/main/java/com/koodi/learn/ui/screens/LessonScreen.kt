package com.koodi.learn.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.koodi.learn.R
import com.koodi.learn.domain.Issue
import com.koodi.learn.ui.Feedback
import com.koodi.learn.ui.UiState
import com.koodi.learn.ui.components.CodeBlock
import com.koodi.learn.ui.components.CodeEditor
import com.koodi.learn.ui.components.HtmlPreview
import com.koodi.learn.ui.components.SectionCard
import kotlinx.coroutines.delay

@Composable
fun LessonScreen(
    state: UiState,
    onDraftChange: (String) -> Unit,
    onCheck: () -> Unit,
    onHint: () -> Unit,
    onReset: () -> Unit,
    onNext: () -> Unit,
    onBack: () -> Unit,
) {
    val lesson = state.lesson
    val colors = MaterialTheme.colorScheme
    val context = LocalContext.current
    val copiedMessage = stringResource(R.string.copied)
    val isLast = state.lessonIndex == state.lessons.lastIndex

    // المعاينة تتأخر 350ms بعد آخر ضغطة بدل إعادة تحميل WebView مع كل حرف
    var previewCode by remember(lesson.id) { mutableStateOf(state.draft) }
    LaunchedEffect(state.draft) {
        delay(350)
        previewCode = state.draft
    }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.lesson_counter, state.lessonIndex + 1, state.lessons.size),
                    color = colors.onSurfaceVariant,
                    fontSize = 12.sp,
                )
                LinearProgressIndicator(
                    progress = { (state.lessonIndex + 1f) / state.lessons.size },
                    modifier = Modifier.fillMaxWidth(),
                    color = colors.primary,
                    trackColor = colors.surfaceVariant,
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 12.dp),
        ) {
            item {
                Text(lesson.title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(lesson.subtitle, color = colors.onSurfaceVariant)
            }
            item {
                SectionCard(stringResource(R.string.section_idea)) {
                    Text(lesson.explanation, lineHeight = 24.sp)
                }
            }
            item {
                SectionCard(stringResource(R.string.section_example)) {
                    CodeBlock(lesson.example)
                    TextButton(onClick = {
                        copyToClipboard(context, lesson.example)
                        Toast.makeText(context, copiedMessage, Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.copy_example))
                    }
                }
            }
            item {
                SectionCard(stringResource(R.string.section_task)) {
                    Text(lesson.task, lineHeight = 23.sp)
                    Text(
                        stringResource(R.string.editor_label),
                        color = colors.onSurfaceVariant,
                        fontSize = 12.sp,
                    )
                    CodeEditor(value = state.draft, onValueChange = onDraftChange)

                    Button(onClick = onCheck, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.check))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = onHint,
                            enabled = state.hintsShown < lesson.hints.size,
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Default.Lightbulb, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.hint_button, state.hintsShown, lesson.hints.size))
                        }
                        TextButton(onClick = onReset, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.reset_code))
                        }
                    }

                    lesson.hints.take(state.hintsShown).forEach { hint ->
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = colors.error,
                                modifier = Modifier.padding(top = 2.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(hint, color = colors.onSurfaceVariant, fontSize = 13.sp, lineHeight = 20.sp)
                        }
                    }
                    state.feedback?.let { FeedbackBanner(it) }
                }
            }
            item {
                SectionCard(stringResource(R.string.section_preview)) {
                    HtmlPreview(previewCode)
                }
            }
        }

        if (!state.isLessonCompleted) {
            Text(
                stringResource(R.string.locked_next_hint),
                color = colors.onSurfaceVariant,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 6.dp),
            )
        }
        Button(
            onClick = onNext,
            enabled = state.isLessonCompleted,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).height(52.dp),
        ) {
            Text(stringResource(if (isLast) R.string.finish_path else R.string.next_lesson))
        }
    }
}

@Composable
private fun FeedbackBanner(feedback: Feedback) {
    val success = feedback is Feedback.Success
    val color = if (success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (success) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = color,
        )
        Spacer(Modifier.width(8.dp))
        Text(feedbackText(feedback), color = color, fontSize = 13.sp)
    }
}

@Composable
private fun feedbackText(feedback: Feedback): String = when (feedback) {
    Feedback.Success -> stringResource(R.string.feedback_success)
    is Feedback.Failure -> when (val issue = feedback.issue) {
        Issue.Empty -> stringResource(R.string.issue_empty)
        is Issue.Unclosed -> stringResource(R.string.issue_unclosed, issue.tag)
        is Issue.MissingTag -> stringResource(R.string.issue_missing_tag, issue.tag)
        is Issue.UnexpectedTag -> stringResource(R.string.issue_unexpected_tag, issue.tag)
        is Issue.Attribute -> stringResource(R.string.issue_attribute, issue.name)
        Issue.WrongText -> stringResource(R.string.issue_text)
        Issue.Structure -> stringResource(R.string.issue_structure)
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    manager.setPrimaryClip(ClipData.newPlainText("code", text))
}
