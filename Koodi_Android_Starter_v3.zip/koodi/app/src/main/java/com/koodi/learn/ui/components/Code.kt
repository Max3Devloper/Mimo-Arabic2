package com.koodi.learn.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.koodi.learn.ui.theme.CodeTextStyle
import com.koodi.learn.ui.theme.KoodiColors

private val TAG_REGEX = Regex("</?[a-zA-Z][^>]*>")
private val STRING_REGEX = Regex("\"[^\"]*\"|'[^']*'")

/** تلوين بسيط للوسوم والقيم النصية. لا يغيّر طول النص، فالمؤشر يبقى سليماً. */
fun highlightHtml(code: String): AnnotatedString = buildAnnotatedString {
    append(code)
    for (tag in TAG_REGEX.findAll(code)) {
        addStyle(SpanStyle(color = KoodiColors.Mint), tag.range.first, tag.range.last + 1)
        for (str in STRING_REGEX.findAll(tag.value)) {
            addStyle(
                SpanStyle(color = KoodiColors.Amber),
                tag.range.first + str.range.first,
                tag.range.first + str.range.last + 1,
            )
        }
    }
}

private object HtmlVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText =
        TransformedText(highlightHtml(text.text), OffsetMapping.Identity)
}

/** عرض كود للقراءة فقط، دائماً من اليسار لليمين حتى لا تنعكس علامات < >. */
@Composable
fun CodeBlock(code: String, modifier: Modifier = Modifier) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            color = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(12.dp),
            modifier = modifier.fillMaxWidth(),
        ) {
            Text(
                text = highlightHtml(code),
                style = CodeTextStyle,
                modifier = Modifier.padding(12.dp),
            )
        }
    }
}

/** محرر الكود: LTR وخط أحادي وتلوين، ويقبل كتابة نص عربي داخل الوسوم. */
@Composable
fun CodeEditor(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = modifier.fillMaxWidth().heightIn(min = 130.dp),
            textStyle = CodeTextStyle,
            visualTransformation = HtmlVisualTransformation,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                cursorColor = MaterialTheme.colorScheme.primary,
            ),
        )
    }
}
