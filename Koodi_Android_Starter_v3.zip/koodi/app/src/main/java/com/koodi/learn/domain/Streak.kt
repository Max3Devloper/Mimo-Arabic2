package com.koodi.learn.domain

/** آخر يوم نشاط (كرقم أيام منذ 1970) وطول السلسلة المحفوظ. */
data class StreakState(val lastEpochDay: Long?, val count: Int)

/** منطق السلسلة اليومية، دالات نقية تُختبر دون Android. */
object StreakCalculator {

    /** يُستدعى عند نجاح المتعلم في تحدٍّ اليوم. */
    fun onActivity(state: StreakState, today: Long): StreakState {
        val last = state.lastEpochDay ?: return StreakState(today, 1)
        return when {
            last == today -> state
            last == today - 1 -> StreakState(today, state.count + 1)
            else -> StreakState(today, 1)
        }
    }

    /** القيمة المعروضة: تنقطع السلسلة إن فات يوم كامل دون نشاط. */
    fun displayed(state: StreakState, today: Long): Int {
        val last = state.lastEpochDay ?: return 0
        return if (today - last <= 1) state.count else 0
    }
}
