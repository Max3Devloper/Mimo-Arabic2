package com.koodi.learn.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp

object KoodiColors {
    val Ink = Color(0xFF101827)
    val Panel = Color(0xFF1B2638)
    val PanelHigh = Color(0xFF243249)
    val Mint = Color(0xFF35D6A0)
    val MintDeep = Color(0xFF174D40)
    val Muted = Color(0xFF9AA8BC)
    val Amber = Color(0xFFFFC36A)
    val Outline = Color(0xFF3A4A63)
    val Text = Color(0xFFF2F5FA)
}

private val DarkColors = darkColorScheme(
    primary = KoodiColors.Mint,
    onPrimary = KoodiColors.Ink,
    primaryContainer = KoodiColors.MintDeep,
    onPrimaryContainer = KoodiColors.Mint,
    secondaryContainer = KoodiColors.MintDeep,
    onSecondaryContainer = KoodiColors.Mint,
    background = KoodiColors.Ink,
    onBackground = KoodiColors.Text,
    surface = KoodiColors.Panel,
    onSurface = KoodiColors.Text,
    surfaceVariant = KoodiColors.PanelHigh,
    onSurfaceVariant = KoodiColors.Muted,
    outline = KoodiColors.Outline,
    error = KoodiColors.Amber,
)

/** نمط الكود: خط أحادي المسافة، واتجاه LTR دائماً حتى داخل واجهة عربية. */
val CodeTextStyle = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontSize = 13.sp,
    lineHeight = 21.sp,
    textDirection = TextDirection.Ltr,
    textAlign = TextAlign.Left,
)

/**
 * الواجهة عربية بالكامل فنفرض RTL لها،
 * أما الكود البرمجي فيُعزل داخل CompositionLocalProvider بـ LTR (انظر CodeBlock وCodeEditor).
 */
@Composable
fun KoodiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            content()
        }
    }
}
