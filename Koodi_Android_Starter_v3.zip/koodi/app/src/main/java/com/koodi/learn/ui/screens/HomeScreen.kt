package com.koodi.learn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.koodi.learn.R
import com.koodi.learn.ui.UiState
import com.koodi.learn.ui.components.StatCard
import com.koodi.learn.ui.components.panelColors

@Composable
fun HomeScreen(state: UiState, onContinue: () -> Unit, onOpenPath: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val total = state.lessons.size

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.home_greeting), color = colors.onSurfaceVariant)
                    Text(
                        stringResource(R.string.home_headline),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Box(
                    modifier = Modifier.size(48.dp).background(colors.primary, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.Code, contentDescription = null, tint = colors.onPrimary)
                }
            }
        }

        item {
            Card(colors = panelColors(), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.goal_title), color = colors.onSurfaceVariant)
                    Text(
                        stringResource(R.string.goal_headline),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else state.doneCount.toFloat() / total },
                        modifier = Modifier.fillMaxWidth(),
                        color = colors.primary,
                        trackColor = colors.surfaceVariant,
                    )
                    Text(
                        stringResource(R.string.progress_summary, state.doneCount, total),
                        color = colors.onSurfaceVariant,
                        fontSize = 12.sp,
                    )
                    Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            stringResource(
                                if (state.allDone) R.string.review_path else R.string.continue_learning,
                            ),
                        )
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    stringResource(R.string.start_path),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                )
                Card(onClick = onOpenPath, modifier = Modifier.fillMaxWidth(), colors = panelColors()) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Language,
                            contentDescription = null,
                            tint = colors.primary,
                            modifier = Modifier.size(38.dp),
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.path_web_title), fontWeight = FontWeight.Bold)
                            Text(
                                stringResource(R.string.path_web_subtitle),
                                color = colors.onSurfaceVariant,
                                fontSize = 13.sp,
                            )
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = colors.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(
                    stringResource(R.string.stat_lessons),
                    stringResource(R.string.stat_lessons_value, state.doneCount, total),
                    Modifier.weight(1f),
                )
                StatCard(
                    stringResource(R.string.stat_streak),
                    stringResource(R.string.streak_days, state.streak),
                    Modifier.weight(1f),
                )
                StatCard(
                    stringResource(R.string.stat_xp),
                    stringResource(R.string.xp_value, state.xp),
                    Modifier.weight(1f),
                )
            }
        }
    }
}
