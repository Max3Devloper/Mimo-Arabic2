package com.koodi.learn.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.koodi.learn.data.LessonRepository
import com.koodi.learn.data.ProgressStore
import com.koodi.learn.domain.HtmlValidator
import com.koodi.learn.domain.Issue
import com.koodi.learn.domain.StreakCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.time.LocalDate

/**
 * يعيش عبر تدوير الشاشة، فلا تضيع الشاشة الحالية ولا المسودة ولا نتيجة التحقق.
 */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ProgressStore(app)
    private val lessons = LessonRepository(app).load()

    private val _state = MutableStateFlow(initialState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private fun today(): Long = LocalDate.now().toEpochDay()

    private fun initialState(): UiState {
        val index = lessons.indexOfFirst { it.id == store.currentLessonId() }.coerceAtLeast(0)
        return UiState(
            lessons = lessons,
            lessonIndex = index,
            draft = store.draft(lessons[index].id) ?: lessons[index].starter,
            completedIds = store.completedIds(),
            streak = StreakCalculator.displayed(store.streak(), today()),
        )
    }

    fun navigate(screen: Screen) = _state.update { it.copy(screen = screen) }

    /** زر الرجوع: من الدرس إلى المسار، ومن المسار أو الحساب إلى الرئيسية. */
    fun back() = _state.update {
        when (it.screen) {
            Screen.LESSON -> it.copy(screen = Screen.PATH)
            Screen.PATH, Screen.PROFILE -> it.copy(screen = Screen.HOME)
            Screen.HOME -> it
        }
    }

    fun openLesson(index: Int) {
        val i = index.coerceIn(0, lessons.lastIndex)
        val lesson = lessons[i]
        store.setCurrentLessonId(lesson.id)
        _state.update {
            it.copy(
                screen = Screen.LESSON,
                lessonIndex = i,
                draft = store.draft(lesson.id) ?: lesson.starter,
                feedback = null, // لا تبقى رسالة الدرس السابق ظاهرة
                hintsShown = 0,
            )
        }
    }

    /** يفتح أول درس لم يكتمل، أو الأول إن اكتملت كل الدروس. */
    fun continueLearning() {
        val s = _state.value
        val next = s.lessons.indexOfFirst { it.id !in s.completedIds }
        openLesson(if (next >= 0) next else 0)
    }

    fun onDraftChange(text: String) {
        val id = _state.value.lesson.id
        store.saveDraft(id, text)
        _state.update { it.copy(draft = text, feedback = null) }
    }

    fun resetDraft() {
        val lesson = _state.value.lesson
        store.saveDraft(lesson.id, lesson.starter)
        _state.update { it.copy(draft = lesson.starter, feedback = null) }
    }

    fun showHint() = _state.update {
        it.copy(hintsShown = (it.hintsShown + 1).coerceAtMost(it.lesson.hints.size))
    }

    fun check() {
        val s = _state.value
        val result = HtmlValidator.validate(s.draft, s.lesson.solutions)
        if (!result.passed) {
            _state.update { it.copy(feedback = Feedback.Failure(result.issue ?: Issue.Structure)) }
            return
        }
        store.markCompleted(s.lesson.id)
        val updated = StreakCalculator.onActivity(store.streak(), today())
        store.saveStreak(updated)
        _state.update {
            it.copy(
                feedback = Feedback.Success,
                completedIds = it.completedIds + s.lesson.id,
                streak = StreakCalculator.displayed(updated, today()),
            )
        }
    }

    fun next() {
        val s = _state.value
        if (s.lessonIndex < s.lessons.lastIndex) openLesson(s.lessonIndex + 1) else navigate(Screen.PATH)
    }
}
