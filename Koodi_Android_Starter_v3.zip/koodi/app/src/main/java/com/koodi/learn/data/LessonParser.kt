package com.koodi.learn.data

import com.koodi.learn.domain.Lesson
import org.json.JSONArray
import org.json.JSONObject

/** يحوّل نص lessons.json إلى قائمة دروس. منفصل عن Android ليسهل اختباره. */
object LessonParser {

    fun parse(json: String): List<Lesson> {
        val array = JSONObject(json).getJSONArray("lessons")
        return List(array.length()) { i ->
            val o = array.getJSONObject(i)
            Lesson(
                id = o.getString("id"),
                title = o.getString("title"),
                subtitle = o.getString("subtitle"),
                explanation = o.getString("explanation"),
                example = o.getString("example"),
                task = o.getString("task"),
                starter = o.getString("starter"),
                solutions = o.getJSONArray("solutions").toStringList(),
                hints = o.getJSONArray("hints").toStringList(),
            )
        }
    }

    private fun JSONArray.toStringList(): List<String> = List(length()) { getString(it) }
}
