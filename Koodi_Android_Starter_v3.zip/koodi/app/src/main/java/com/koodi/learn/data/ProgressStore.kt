package com.koodi.learn.data

import android.content.Context
import com.koodi.learn.domain.StreakState

/**
 * التخزين المحلي للتقدم. المفاتيح مبنية على id الدرس لا على ترتيبه،
 * فإعادة ترتيب الدروس أو إضافة دروس جديدة لا تفسد تقدم المتعلم.
 * هذه الطبقة هي الوحيدة التي تعرف SharedPreferences، فاستبدالها بـ DataStore أو Room لاحقاً سهل.
 */
class ProgressStore(context: Context) {

    private val prefs = context.getSharedPreferences("koodi_progress", Context.MODE_PRIVATE)

    fun currentLessonId(): String? = prefs.getString(KEY_CURRENT, null)

    fun setCurrentLessonId(id: String) {
        prefs.edit().putString(KEY_CURRENT, id).apply()
    }

    fun draft(lessonId: String): String? = prefs.getString("draft_$lessonId", null)

    fun saveDraft(lessonId: String, code: String) {
        prefs.edit().putString("draft_$lessonId", code).apply()
    }

    fun completedIds(): Set<String> =
        prefs.getStringSet(KEY_COMPLETED, emptySet())?.toSet() ?: emptySet()

    fun markCompleted(lessonId: String) {
        // نسخة جديدة دائماً: لا يجوز تعديل المجموعة التي يرجعها getStringSet
        prefs.edit().putStringSet(KEY_COMPLETED, completedIds() + lessonId).apply()
    }

    fun streak(): StreakState {
        val last = if (prefs.contains(KEY_STREAK_DAY)) prefs.getLong(KEY_STREAK_DAY, 0L) else null
        return StreakState(last, prefs.getInt(KEY_STREAK_COUNT, 0))
    }

    fun saveStreak(state: StreakState) {
        prefs.edit().apply {
            state.lastEpochDay?.let { putLong(KEY_STREAK_DAY, it) }
            putInt(KEY_STREAK_COUNT, state.count)
        }.apply()
    }

    private companion object {
        const val KEY_CURRENT = "current"
        const val KEY_COMPLETED = "completed"
        const val KEY_STREAK_DAY = "streak_day"
        const val KEY_STREAK_COUNT = "streak_count"
    }
}
